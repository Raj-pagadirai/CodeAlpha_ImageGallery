# Image Gallery – CodeAlpha Internship Task

## 📌 Project Description

This is a responsive Image Gallery built using **HTML**, **CSS**, and **JavaScript**. It includes a lightbox view with next/previous navigation and hover effects. This project was developed as part of the CodeAlpha Frontend Development Internship.

## 🔧 Features

- Lightbox modal with next/prev buttons
- Responsive design for all screen sizes
- Smooth transitions and hover zoom effects
- Modular HTML, CSS, and JS structure
- Click to enlarge image functionality

## 📁 Folder Structure

```
ImageGallery/
│
├── index.html
├── style.css
├── script.js
└── images/
    ├── img1.jpg
    ├── img2.jpg
    └── img3.jpg
```

> 🔔 Add your own images to the `images/` folder named as `img1.jpg`, `img2.jpg`, `img3.jpg`.

## 🚀 How to Run Locally

1. Clone the repo or download ZIP
2. Add 3 images in the `/images` folder
3. Open `index.html` in any browser

## 🎥 Demo

_A demo video is available on my LinkedIn profile along with this project's GitHub repo link._

## 📌 Task Reference

This project corresponds to:

> ✅ **TASK 1: Image Gallery**  
> CodeAlpha Frontend Internship Tasks

## 📇 Author

[Your Name]  
[Your LinkedIn Profile]